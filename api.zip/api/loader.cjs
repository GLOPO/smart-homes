// Source - https://stackoverflow.com/a
// Posted by Hime-sama
// Retrieved 2025-11-28, License - CC BY-SA 4.0

async function loadApp() {
    await import("./index.js");
}

loadApp();
